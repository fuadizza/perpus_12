       <!-- menu tengah -->
		
		<!-- Main Content -->
		<!--<div class="row">
			<li class="container-fluid">
				<div class="table-responsive">
					<table class ="table">
						<tbody>
							<tr>
								<td align="center"><a href="?page=buku"><img src="../images/buku.png" width="100" height="100"></a><br /><center>Data Buku</center></td>
								<td align="center"><a href="?page=anggota"><img src="../images/anggota.png" width="100" height="100"></a><br /><center>Anggota</center></td>
							</tr>
							<tr>	
								<td  align="center"><a href="?page=transaksi"><img src="../images/user.ico" width="100" height="100"></a></a><br /><center>Transaksi</center></td>
								<td  align="center"><a href="?page=laporan"><img src="../images/laporan.png" width="100" height="100"></a><br /><center>Laporan</center></td>
							</tr>         
						</tbody>
					</table>		  
				</div>
			</li>
		</div>-->
		<script type="text/javascript">
			body {
        background-color: #444;
        background: url(http://s18.postimg.org/l7yq0ir3t/pick8_1.jpg);
        
    }
		</script>

		<div class="col-sm-10">
			<div class="well">
				<center>
				<img src="../logo.png" width=10% height=10% alt="">
				<h4>SELAMAT DATANG DI HALAMAN PORTALPERPUSTAKAAN DINAS KEPENDUDUKAN DAN CATATAN SIPIL</h4>
				<p>Silahkan Pilih Menu dibawah ini</p></center>
			</div>
		</div>
		
		
		
			<div class="col-sm-5">
				<div class="thumbnail">
					<a href="?page=buku"><img src="../images/buku.png" width=40% height="100"></a><br /><center>Data Buku</center>
				</div>
			</div>
		
			<div class="col-sm-5">
				<div class="thumbnail">
						<a href="?page=anggota"><img src="../images/anggota.png" width= 40% height="100"></a><br /><center>Anggota</center>
				</div>
			</div>
			
			<div class="col-sm-5">
				<div class="thumbnail">
						<a href="?page=transaksi"><img src="../images/user.ico" width= 40% height="100"></a></a><br/><center>Transaksi</center>
				</div>
			</div>
			
			<div class="col-sm-5">
				<div class="thumbnail">
						<a href="?page=laporan"><img src="../images/laporan.png" width= 40% height="100"></a><br /><center>Laporan</center>
				</div>
			</div>
			
			
		
        
        
        