       <!-- menu tengah -->
	<div id="menu-tengah">
    	<div id="bg_menu"><marquee>Welcome to Sistem Informasi Perpustakaan</marquee>
    	</div>
    	<div id="content_menu">
        <div id="menu_header2">
        
        <center>
        ~ Silahkan pilih Panel Dibawah ini ~
        </center>
        
        </div>
        
		<div class="table_home">
          <table width="100%" height="100%" align="center" cellpadding="2" border="0">
          	<tbody>
            	<tr>
                	<td class="img_home" align="center"><a href="?page=buku"><img src="../images/buku.png" width="100" height="100"></a><br />
                    <center>Data Buku</center></td>
                    <td class="img_home" align="center"><a href="?page=anggota"><img src="../images/anggota.png" width="100" height="100"></a><br /><center>Anggota</center></td>
                    <td class="img_home" align="center"><a href="?page=transaksi"><img src="../images/user.ico" width="100" height="100"></a></a><br /><center>Transaksi</center></td>
                    <td class="img_home" align="center"><a href="?page=laporan"><img src="../images/laporan.png" width="100" height="100"></a><br /><center>Laporan</center></td>
                    
                </tr>
                
            
            </tbody>
          </table>  
          </div>
            
	  </div>
    </div>